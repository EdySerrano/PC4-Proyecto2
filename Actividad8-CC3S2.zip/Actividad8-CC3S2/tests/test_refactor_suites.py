# tests/test_refactor_suites.py
import pytest
from unittest.mock import Mock
from src.shopping_cart import ShoppingCart


class TestPrecisionMonetaria:
    """Suite de pruebas enfocada en la precisión monetaria y cálculos financieros"""
    
    def test_suma_pequenas_cantidades(self):
        # Arrange
        cart = ShoppingCart()
        cart.add_item("x", 1, 0.05)  # nombre, cantidad, precio unitario
        cart.add_item("y", 1, 0.05)  # segundo item con mismo precio
        
        # Act
        total = cart.calculate_total()
        
        # Assert
        assert round(total, 2) == 0.10

    def test_precision_con_decimales(self):
        # Arrange
        cart = ShoppingCart()
        cart.add_item("item1", 3, 0.33)  # 3 * 0.33 = 0.99
        cart.add_item("item2", 1, 0.01)  # 1 * 0.01 = 0.01
        
        # Act
        total = cart.calculate_total()
        
        # Assert
        assert round(total, 2) == 1.00
    
    def test_redondeo_consistente(self):
        # Arrange
        cart = ShoppingCart()
        cart.add_item("producto", 7, 0.1429)  # 7 * 0.1429 = 1.0003
        
        # Act
        total = cart.calculate_total()
        
        # Assert
        # Verifica que el redondeo es consistente a 2 decimales
        assert total == 1.00

    def test_aplicacion_descuento_precision(self):
        # Arrange
        cart = ShoppingCart()
        cart.add_item("item", 3, 3.33)  # 3 * 3.33 = 9.99
        cart.apply_discount(10)  # 10% de descuento
        
        # Act
        total = cart.calculate_total()
        
        # Assert
        expected = round(9.99 * 0.9, 2)  # 8.991 -> 8.99
        assert total == expected


class TestPasarelaPagoContratos:
    """Suite de pruebas enfocada en contratos de pasarelas de pago y procesamiento"""
    
    def test_pago_exitoso(self):
        # Arrange
        payment_gateway = Mock()
        payment_gateway.process_payment.return_value = True
        cart = ShoppingCart(payment_gateway=payment_gateway)
        cart.add_item("producto", 1, 10.0)
        
        # Act
        resultado = cart.process_payment(10.0)
        
        # Assert
        assert resultado is True
        payment_gateway.process_payment.assert_called_once_with(10.0)
    
    def test_pago_fallido(self):
        # Arrange
        payment_gateway = Mock()
        payment_gateway.process_payment.return_value = False
        cart = ShoppingCart(payment_gateway=payment_gateway)
        cart.add_item("producto", 1, 5.0)
        
        # Act
        resultado = cart.process_payment(5.0)
        
        # Assert
        assert resultado is False
        payment_gateway.process_payment.assert_called_once_with(5.0)
    
    def test_excepcion_sin_pasarela(self):
        # Arrange
        cart = ShoppingCart()  # Sin pasarela de pago
        cart.add_item("producto", 1, 15.0)
        
        # Act & Assert
        with pytest.raises(ValueError, match="No se proporciona pasarela de pago"):
            cart.process_payment(15.0)
    
    def test_excepcion_en_procesamiento(self):
        # Arrange
        payment_gateway = Mock()
        payment_gateway.process_payment.side_effect = Exception("Error de red")
        cart = ShoppingCart(payment_gateway=payment_gateway)
        cart.add_item("producto", 1, 20.0)
        
        # Act & Assert
        with pytest.raises(Exception, match="Error de red"):
            cart.process_payment(20.0)
    
    def test_monto_con_descuento(self):
        # Arrange
        payment_gateway = Mock()
        payment_gateway.process_payment.return_value = True
        cart = ShoppingCart(payment_gateway=payment_gateway)
        cart.add_item("producto", 2, 25.0)  # 50.0 total
        cart.apply_discount(20)  # 20% descuento = 40.0
        
        # Act
        total = cart.calculate_total()
        resultado = cart.process_payment(total)
        
        # Assert
        assert resultado is True
        assert total == 40.0
        payment_gateway.process_payment.assert_called_once_with(40.0)