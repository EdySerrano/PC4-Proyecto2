# tests/test_pasarela_pago_contratos.py
import pytest
from unittest.mock import Mock
from src.shopping_cart import ShoppingCart


def test_pago_exitoso():
    # Arrange
    pg = Mock()
    pg.process_payment.return_value = True
    cart = ShoppingCart(payment_gateway=pg)
    cart.add_item("x", 1, 10.0)  # nombre, cantidad, precio
    total = cart.calculate_total()
    
    # Act
    resultado = cart.process_payment(total)
    
    # Assert
    assert resultado is True
    pg.process_payment.assert_called_once_with(total)


def test_pago_timeout_sin_reintento_automatico():
    # Arrange
    pg = Mock()
    pg.process_payment.side_effect = TimeoutError("timeout")
    cart = ShoppingCart(payment_gateway=pg)
    cart.add_item("x", 1, 10.0)
    total = cart.calculate_total()
    
    # Act / Assert
    with pytest.raises(TimeoutError):
        cart.process_payment(total)
    
    # El SUT no debe reintentar automáticamente
    assert pg.process_payment.call_count == 1
    
    # (Opcional) Reintento manual desde el test para documentar el contrato
    pg.process_payment.side_effect = None
    pg.process_payment.return_value = True
    # Reintento manual - simulando lógica del cliente
    retry_result = pg.process_payment(total)
    assert retry_result is True  # reintento manual exitoso


def test_pago_rechazo_definitivo():
    # Arrange
    pg = Mock()
    pg.process_payment.return_value = False
    cart = ShoppingCart(payment_gateway=pg)
    cart.add_item("x", 1, 10.0)
    total = cart.calculate_total()
    
    # Act
    resultado = cart.process_payment(total)
    
    # Assert
    assert resultado is False
    pg.process_payment.assert_called_once_with(total)


def test_pago_excepcion_red_transitoria():
    # Arrange
    pg = Mock()
    pg.process_payment.side_effect = ConnectionError("Error de red")
    cart = ShoppingCart(payment_gateway=pg)
    cart.add_item("producto", 1, 25.0)
    total = cart.calculate_total()
    
    # Act / Assert
    with pytest.raises(ConnectionError):
        cart.process_payment(total)
    
    # Verificar que no hay reintento automático
    assert pg.process_payment.call_count == 1


def test_pago_excepcion_invalida():
    # Arrange
    pg = Mock()
    pg.process_payment.side_effect = ValueError("Tarjeta inválida")
    cart = ShoppingCart(payment_gateway=pg)
    cart.add_item("servicio", 1, 50.0)
    total = cart.calculate_total()
    
    # Act / Assert
    with pytest.raises(ValueError, match="Tarjeta inválida"):
        cart.process_payment(total)
    
    # Verificar que se llama una sola vez (sin reintentos)
    assert pg.process_payment.call_count == 1


def test_contrato_sin_pasarela():
    # Arrange
    cart = ShoppingCart()  # Sin pasarela de pago
    cart.add_item("item", 1, 15.0)
    total = cart.calculate_total()
    
    # Act / Assert
    with pytest.raises(ValueError, match="No se proporciona pasarela de pago"):
        cart.process_payment(total)


def test_pago_con_monto_cero():
    # Arrange
    pg = Mock()
    pg.process_payment.return_value = True
    cart = ShoppingCart(payment_gateway=pg)
    # No agregar items, total será 0.0
    total = cart.calculate_total()
    
    # Act
    resultado = cart.process_payment(total)
    
    # Assert
    assert resultado is True
    assert total == 0.0
    pg.process_payment.assert_called_once_with(0.0)