# Análisis del Ejercicio A1: Descuentos Parametrizados

## A1. Descuentos parametrizados

### Descripción
Se creó el archivo `tests/test_descuentos_parametrizados.py` con casos de prueba parametrizados que verifican el cálculo de totales con diferentes descuentos aplicados sobre productos con diversos precios y cantidades.

### Implementación
- Se utilizó el patrón AAA (Arrange, Act, Assert) comentado en cada prueba
- Se implementaron 6 casos de prueba parametrizados con `@pytest.mark.pEstado: **4 MREs creados y documentados**

## D1: Estabilidad con Datos AleatoriosEstado: **4 MREs creados y documentados**

## D2: Invariantes de Inventario

### Implementación

Creamos `tests/test_invariantes_inventario.py` con 5 tests que validan invariantes fundamentales del carrito de compras para prevenir regresiones en la lógica de negocio.

### Invariantes Validados

#### 1. Invariante Principal: Reversibilidad Completa
```python
def test_invariante_agregar_remover():
    c.agregar_producto(producto, N)  # Estado: tiene N items
    c.remover_producto(producto, N)  # Estado: vacío
    assert c.calcular_total() == 0.0 and c.contar_items() == 0
```
**Propósito**: Garantiza que agregar N y luego remover N vuelve al estado inicial vacío

#### 2. Invariante de Consistencia Parcial
```python
def test_invariante_agregar_remover_parcial():
    c.agregar_producto(producto, 5)  # Total: 37.5
    c.remover_producto(producto, 2)  # Total: 22.5, Items: 3
    assert estado_matemáticamente_correcto
```
**Propósito**: Las operaciones parciales mantienen consistencia matemática

#### 3. Invariante de Acumulación Sin Duplicación
```python
def test_invariante_idempotencia_agregar():
    c.agregar_producto(mismo_producto, varias_veces)
    assert len(c.items) == 1  # Solo un tipo de producto
    assert suma_cantidades_correcta
```
**Propósito**: Agregar el mismo producto acumula cantidades, no crea duplicados

#### 4. Invariante de Aislamiento entre Productos
```python
def test_invariante_multiples_productos():
    # Operar en producto_A no debe afectar producto_B
    assert producto_B_inalterado_tras_operaciones_en_A
```
**Propósito**: Las operaciones en un producto no afectan otros productos

#### 5. Invariante de Ciclo Completo
```python
def test_invariante_agregar_remover_completo():
    estado_inicial = estado_vacio
    # ... operaciones ...
    estado_final = estado_vacio_tras_ciclo_completo
    assert estado_inicial == estado_final
```
**Propósito**: Un ciclo completo de operaciones vuelve al estado original

### Prevención de Regresiones

#### 🛡️ Por qué los Invariantes Previenen Regresiones

1. **Detección Temprana de Bugs**:
   - Los invariantes fallan inmediatamente si se introduce lógica incorrecta
   - Ejemplo: Si `remover_producto` no elimina correctamente, el invariante "agregar N, remover N -> vacío" falla

2. **Validación de Comportamiento Esperado**:
   - Garantizan que las operaciones fundamentales siempre funcionen correctamente
   - Ejemplo: Agregar el mismo producto debe acumular, no duplicar entradas

3. **Protección contra Cambios Accidentales**:
   - Si alguien modifica la lógica de carrito, los invariantes detectan comportamientos inesperados
   - Ejemplo: Si `agregar_producto` deja de acumular cantidades correctamente

4. **Validación de Estado Consistente**:
   - Aseguran que el carrito siempre está en un estado matemáticamente válido
   - Ejemplo: Total = suma(precio × cantidad) para todos los items

5. **Cobertura de Casos Edge**:
   - Los invariantes cubren operaciones límite (vacío, remoción completa, etc.)
   - Ejemplo: Remover todo debe dejar el carrito completamente vacío

#### 📋 Casos de Regresión Prevenidos

- **Bug en remoción**: Si `remover_producto` no elimina items correctamente
- **Bug en acumulación**: Si agregar productos crea duplicados en lugar de acumular
- **Bug en cálculos**: Si `calcular_total` o `contar_items` dan resultados incorrectos
- **Bug de aislamiento**: Si operaciones en un producto afectan otros productos
- **Bug de estado**: Si el carrito queda en estado inconsistente tras operaciones

#### Valor para Mantenimiento

1. **Refactoring Seguro**: Los invariantes permiten refactorizar con confianza
2. **Testing Regression**: Detectan automáticamente cuando se rompe funcionalidad existente
3. **Documentación Ejecutable**: Los invariantes documentan comportamientos esperados
4. **Validación Continua**: Se ejecutan en cada cambio para mantener consistencia

### Limitaciones Encontradas

Durante la implementación se detectó un bug en el código fuente:
```python
# En actualizar_cantidad(), línea 62:
if item.producto.nombre == producto.nombre:  # Bug: producto es string
```
Debería ser:
```python
if item.producto.nombre == producto:  # Correcto: comparar con string
```

Este hallazgo demuestra el valor de los tests de invariantes para detectar bugs existentes.

### Aplicaciones Prácticas

Los invariantes de inventario son especialmente valiosos en:
- **E-commerce**: Garantizar consistencia en carritos de compra
- **ERP**: Mantener integridad en movimientos de inventario  
- **POS**: Validar operaciones de punto de venta
- **Warehouse**: Asegurar precisión en gestión de almacenes

Estado: **5 invariantes fundamentales validados y documentados** Controlados

### Implementación

Creamos `tests/test_estabilidad_semillas.py` con 4 tests que demuestran control determinístico de datos aleatorios mediante semillas fijas.

### Tests de Estabilidad Implementados

#### 1. Test Básico de Estabilidad
```python
def test_estabilidad_semillas_basico():
    random.seed(123); Faker.seed(123)
    p1 = ProductoFactory(); c1 = Carrito()
    c1.agregar_producto(p1, 2); total1 = c1.calcular_total()
    # Segunda corrida con mismas semillas produce resultados idénticos
```
**Verificación**: Mismo producto, precio y total en ambas ejecuciones

#### 2. Test Múltiples Productos Aleatorios  
```python
def test_estabilidad_multiples_productos():
    # 5 productos con cantidades aleatorias (1-10)
    random.seed(456); Faker.seed(456)
    # Genera carrito complejo con datos determinísticos
```
**Verificación**: Mismo número de items y total con semilla 456

#### 3. Test Inestabilidad Sin Semillas
```python
def test_inestabilidad_sin_semillas():
    # Dos corridas SIN semillas fijas
    # Demuestra variabilidad cuando no hay control
```
**Contraste**: Sin semillas, productos son diferentes (como esperado)

#### 4. Test Estabilidad con Descuentos
```python  
def test_estabilidad_con_descuentos():
    # Descuentos aleatorios (10-50%) sobre carritos aleatorios
    random.seed(789); Faker.seed(789)
    # Operaciones complejas con control determinístico
```
**Verificación**: Mismo descuento y total final con semilla 789

### Demostración de Estabilidad

**Ejecución 1 y 2**: Producen resultados idénticos
- Mismos productos generados
- Mismos precios calculados  
- Mismos totales obtenidos
- Mismas salidas capturadas

### Configuración Técnica

```python
# Control de semillas para reproducibilidad
random.seed(123)        # Números aleatorios  
Faker.seed(123)         # Datos sintéticos
ProductoFactory()       # Productos determinísticos
capsys.readouterr()     # Captura de salidas
```

### Valor para Testing

1. **Reproducibilidad**: Tests ejecutables con resultados consistentes
2. **Debugging**: Comportamientos predecibles facilitan depuración  
3. **CI/CD**: Elimina fallos por variabilidad aleatoria
4. **Validación**: Permite comparación exacta entre ejecuciones
5. **Regresión**: Detecta cambios reales vs. variaciones aleatorias

### Aplicaciones Prácticas

- **Testing de Algoritmos**: Validar comportamiento con datos controlados
- **Performance Testing**: Medir rendimiento con cargas reproducibles
- **Integration Testing**: Simular escenarios realistas pero consistentes  
- **Load Testing**: Generar datos de prueba determinísticos
- **Chaos Engineering**: Inyectar fallas controladas y reproducibles

La estabilidad con datos aleatorios controlados permite testing robusto combinando realismo (datos variados) con reproducibilidad (resultados consistentes).

Estado: **Estabilidad demostrada con 4 tests y 2 ejecuciones idénticas** rametrize`
- El redondeo se aplicó solo en los asserts usando `round(total, 2)` y `pytest.approx(esperado, abs=0.01)`
- Se adaptó la API existente usando `agregar_producto` en lugar de `agregar` y `aplicar_descuento` con conversión a porcentaje

### Tabla de casos de prueba: Entrada -> Total esperado

| Precio | Cantidad | Descuento | Total Esperado | Descripción |
|--------|----------|-----------|----------------|-------------|
| 10.00  | 1        | 0.00      | 10.00         | Sin descuento |
| 10.00  | 1        | 0.01      | 9.90          | Descuento mínimo del 1% |
| 10.01  | 1        | 0.3333    | 6.67          | Descuento del 33.33% con centavos |
| 100.00 | 1        | 0.50      | 50.00         | Descuento del 50% |
| 1.00   | 1        | 0.9999    | 0.00          | Descuento máximo del 99.99% |
| 50.00  | 1        | 1.00      | 0.00          | Descuento total del 100% |

### Resultados
- Todas las pruebas pasaron exitosamente (6/6)
- La cobertura actual es del 60% que es inferior al 90% requerido
- Se generaron correctamente los archivos `out/junit.xml` y `out/coverage.txt`

## A2. Idempotencia de actualización de cantidades

### Descripción
Se creó el archivo `tests/test_idempotencia_cantidades.py` para verificar que establecer varias veces la misma cantidad no cambia el total ni el número de ítems en el carrito, cumpliendo así con el principio de idempotencia.

### Implementación
- Se utilizó el patrón AAA (Arrange, Act, Assert) comentado en la prueba
- Se adaptó la API existente usando `agregar_producto`, `actualizar_cantidad`, `calcular_total` y `contar_items`
- Se realizó la operación de actualización 5 veces consecutivas para verificar la idempotencia
- Se verificaron tanto el total como el número de ítems antes y después de las operaciones

### Casos verificados
- **Producto**: "x" con precio 3.25
- **Cantidad inicial**: 2 unidades
- **Operación**: Actualizar cantidad a 2 (5 veces consecutivas)
- **Verificaciones**: Total constante (6.50) y número de ítems constante (2)

### Resultados
- La prueba pasa exitosamente (1/1)
- Se comprueba que `actualizar_cantidad` es idempotente
- Total de pruebas en el proyecto: 13/13 pasan
- La cobertura aumentó del 60% al 68%

## A3. Fronteras de precio y valores inválidos

### Descripción
Se creó el archivo `tests/test_precios_frontera.py` para cubrir casos extremos de precios, incluyendo valores frontera y precios inválidos, utilizando `xfail` para casos donde el comportamiento no está definido por el SUT.

### Implementación
- Se utilizó el patrón AAA (Arrange, Act, Assert) comentado en las pruebas
- Se implementaron pruebas parametrizadas para valores frontera usando `@pytest.mark.parametrize`
- Se usó `@pytest.mark.xfail` para precios inválidos donde el contrato no está definido
- Se adaptó la API existente usando `agregar_producto` y `calcular_total`

### Tabla de casos de frontera

| Precio | Descripción | Resultado Esperado |
|--------|-------------|-------------------|
| 0.01 | Precio mínimo positivo | Total ≥ 0 |
| 0.005 | Precio con decimales pequeños | Total ≥ 0 |
| 0.0049 | Precio muy pequeño | Total ≥ 0 |
| 9999999.99 | Precio muy alto | Total ≥ 0 |

### Tabla de casos inválidos (xfail)

| Precio Inválido | Descripción | Comportamiento SUT |
|----------------|-------------|-------------------|
| 0.0 | Precio cero | XPASS - El sistema acepta precio 0 |
| -1.0 | Precio negativo | XPASS - El sistema acepta precios negativos |

### Resultados
- **Pruebas de frontera**: 4/4 pasan
- **Pruebas inválidas**: 2/2 XPASS (comportamiento inesperado)
- **Descubrimiento**: El SUT acepta precios 0 y negativos sin lanzar excepciones
- **Total de pruebas**: 17 pasan, 2 XPASS (19 totales)
- **Cobertura**: Se mantiene en 68%

## A4. Redondeos acumulados vs. final

### Descripción
Se creó el archivo `tests/test_redondeo_acumulado.py` para analizar las diferencias entre redondear el total de cada ítem individualmente versus redondear la suma final, documentando casos donde estos enfoques pueden diferir.

### Implementación
- Se utilizó el patrón AAA (Arrange, Act, Assert) comentado en las pruebas
- Se crearon múltiples casos para explorar diferentes escenarios de redondeo
- Se calculan tanto la suma exacta como los redondeos por ítem y final
- Se documentan las diferencias numéricas para análisis

### Mini-tabla: Suma por ítem / Redondeo final / Diferencia

| Caso | Suma Exacta | Redondeo por Ítem | Redondeo Final | Diferencia |
|------|-------------|-------------------|----------------|------------|
| A: 0.3333×3 + 0.6667×3 | 3.0000 | 3.00 | 3.00 | 0.00 |
| B: 0.125×4 + 0.124×4 | 0.996 | 1.00 | 1.00 | 0.00 |
| C: 0.335×3 + 0.225×4 | 1.905 | 1.91 | 1.91 | ~0.00* |
| D: 1.225×2 + 0.375×4 | 3.950 | 3.95 | 3.95 | 0.00 |

*Diferencia menor a precisión de punto flotante

### Hallazgos importantes
1. **Coherencia del SUT**: El sistema mantiene consistencia entre ambos enfoques de redondeo
2. **Precisión numérica**: Las diferencias observadas son del orden de 10^-16 (errores de punto flotante)
3. **Casos límite**: Incluso en casos diseñados para mostrar diferencias, el comportamiento es consistente
4. **Robustez**: El sistema maneja correctamente los cálculos con múltiples decimales

### Resultados
- **Pruebas de redondeo**: 3/3 pasan
- **Total de pruebas**: 20 pasan, 2 XPASS (22 totales)
- **Cobertura**: Aumentó del 68% al 69%
- **Comportamiento del SUT**: Consistente en manejo de redondeos

## B1. RGR - Rojo (falla esperada) - precisión financiera

### Descripción
Se creó el archivo `tests/test_rgr_precision_rojo.py` con pruebas marcadas como `@pytest.mark.xfail` para demostrar el problema clásico de precisión binaria en operaciones financieras con números de punto flotante.

### Implementación
- Se utilizaron dos pruebas con `@pytest.mark.xfail` para documentar fallas esperadas
- Primera prueba: problema de precisión en cálculo directo sin redondeo
- Segunda prueba: demostración del caso clásico 0.1 + 0.2 != 0.3
- Se usa `ShoppingCart` según las pistas del ejercicio

### Traceback capturado
```
AssertionError: assert 0.30000000000000004 == 0.3
  + where 0.30000000000000004 = sum(...)
```

### Impacto del problema de precisión
- **Error numérico**: 0.1 + 0.2 = 0.30000000000000004 (diferencia: ~5.55e-17)
- **Impacto financiero**: En aplicaciones monetarias, estos errores pueden acumularse y causar discrepancias en balances y cálculos contables
- **Solución**: Uso de tipos decimales (`decimal.Decimal`) en lugar de `float` para operaciones financieras críticas

### Resultados
- **Pruebas con XFAIL**: 2/2 fallan como se esperada
- **Total de pruebas**: 20 pasan, 2 XFAIL, 2 XPASS (24 totales)
- **Cobertura**: Se mantiene en 69%
- **Demostración exitosa**: Se documenta el problema de precisión binaria

## B2. RGR - Verde (exclusión documentada)

### Descripción
Se creó el archivo `tests/test_rgr_precision_verde.py` convirtiendo las pruebas del ejercicio B1 de `@pytest.mark.xfail` a `@pytest.mark.skip`, representando la fase "Verde" del ciclo RGR donde se decide excluir temporalmente la corrección del problema para mantener la estabilidad del pipeline.

### Implementación
- Se convirtieron 2 pruebas de `xfail` a `skip` con razones explícitas y documentadas
- Primera prueba: "Contrato: precisión binaria no se corrige en esta versión"
- Segunda prueba: "Problema de precisión conocido - no implementado en esta versión"
- Mismo setup que el ejercicio B1 pero con exclusión intencional

### Decisión de exclusión documentada
La conversión de `xfail` a `skip` representa una decisión consciente de producto/arquitectura:

**Razones para la exclusión:**
1. **Estabilidad del pipeline**: Evitar fallas en CI/CD por problemas conocidos pero no críticos
2. **Priorización de features**: La precisión decimal no es crítica para esta versión del producto
3. **Complejidad vs beneficio**: Implementar `decimal.Decimal` requiere refactoring extensivo
4. **Retrocompatibilidad**: Cambiar de `float` a `decimal` puede afectar APIs existentes

### Impacto en el desarrollo
- **Pipeline estable**: Las pruebas skipped no causan fallas en builds automáticos
- **Documentación clara**: Las razones explícitas facilitan futuras revisiones
- **Deuda técnica controlada**: El problema está documentado para abordarse en versiones futuras

### Resultados
- **Pruebas skipped**: 2/2 se omiten correctamente
- **Total de pruebas**: 20 pasan, 2 SKIPPED, 2 XFAIL, 2 XPASS (26 totales)
- **Cobertura**: Se mantiene en 69%
- **Pipeline verde**: Sin fallas por problemas de precisión conocidos

## B3. RGR - Refactor de suites

### Descripción
Se creó el archivo `tests/test_refactor_suites.py` reorganizando casos de prueba en dos clases especializadas por dominio: `TestPrecisionMonetaria` y `TestPasarelaPagoContratos`, mejorando la legibilidad y mantenibilidad sin duplicar lógica.

### Implementación de la reorganización
Se aplicaron principios de Single Responsibility Principle (SRP) para agrupar pruebas relacionadas:

**Clase `TestPrecisionMonetaria`:** (4 pruebas)
- `test_suma_pequenas_cantidades`: Verificación de sumas de decimales pequeños
- `test_precision_con_decimales`: Prueba de precisión con valores decimales diversos
- `test_redondeo_consistente`: Validación del redondeo a 2 decimales
- `test_aplicacion_descuento_precision`: Precisión en cálculo de descuentos

**Clase `TestPasarelaPagoContratos`:** (5 pruebas)
- `test_pago_exitoso`: Flujo exitoso de procesamiento de pago
- `test_pago_fallido`: Manejo de pagos rechazados
- `test_excepcion_sin_pasarela`: Validación de excepción por falta de pasarela
- `test_excepcion_en_procesamiento`: Manejo de excepciones durante el procesamiento
- `test_monto_con_descuento`: Integración de descuentos con procesamiento de pago

### Beneficios de la reorganización

**Legibilidad mejorada:**
- **Agrupación semántica**: Pruebas relacionadas agrupadas por dominio funcional
- **Nombres descriptivos**: Clases con nombres que reflejan claramente su propósito
- **Documentación inline**: Docstrings explicativas para cada clase de prueba
- **Navegación facilitada**: Estructura jerárquica en reportes de pruebas

**Mantenibilidad incrementada:**
- **Separación de responsabilidades**: Cada clase se enfoca en un aspecto específico
- **Reutilización de setup**: Patrones comunes identificables dentro de cada clase
- **Evolución independiente**: Cambios en un dominio no afectan al otro
- **Cobertura dirigida**: Fácil identificación de gaps por dominio

**Sin duplicación de lógica:**
- **Setup compartido**: Patrones de Arrange reutilizables dentro de cada clase
- **Assertions consistentes**: Estilo unificado por dominio
- **Mocks reutilizados**: Configuración de mocks coherente en pruebas de pago

### Impacto en cobertura y métricas

**Mejora significativa en cobertura:**
- **shopping_cart.py**: 90% → 93% (+3%)
- **Cobertura total**: 69% → 70% (+1%)
- **Nuevas líneas cubiertas**: Manejo de excepciones y casos edge

**Métricas de calidad:**
- **Casos edge cubiertos**: Excepciones y flujos alternativos
- **Contratos validados**: Interacciones con mocks verificadas
- **Precisión documentada**: Comportamiento decimal explícito

### Resultados
- **Pruebas refactorizadas**: 9/9 pasan correctamente
- **Total de pruebas**: 29 pasan, 2 SKIPPED, 2 XFAIL, 2 XPASS (35 totales)
- **Cobertura mejorada**: Del 69% al 70% (+1%)
- **Refactor exitoso**: Mejor organización sin duplicación de lógica

## C1. Contratos de pasarela de pago con mock

### Descripción
Se creó el archivo `tests/test_pasarela_pago_contratos.py` para validar exhaustivamente los contratos de interacción con pasarelas de pago externas, cubriendo escenarios de éxito, fallos transitorios y rechazos definitivos usando mocks.

### Implementación
Se desarrollaron 7 pruebas que cubren todos los escenarios críticos de procesamiento de pagos:
- **Éxito**: Pago procesado correctamente
- **Timeout**: Excepción transitoria sin reintento automático
- **Rechazo**: Respuesta definitiva negativa
- **Errores de red**: Excepciones de conectividad
- **Errores de validación**: Datos inválidos
- **Sin pasarela**: Validación de configuración requerida
- **Monto cero**: Caso edge de transacciones gratuitas

### Tabla: Evento -> Expectativa

| Evento | Mock Configuración | Expectativa del SUT | Verificación |
|--------|-------------------|-------------------|--------------|
| **Pago exitoso** | `process_payment.return_value = True` | Retorna `True` | Una llamada al mock |
| **Timeout transitorio** | `process_payment.side_effect = TimeoutError` | Lanza `TimeoutError` | Sin reintentos automáticos (1 llamada) |
| **Rechazo definitivo** | `process_payment.return_value = False` | Retorna `False` | Una llamada al mock |
| **Error de red** | `process_payment.side_effect = ConnectionError` | Lanza `ConnectionError` | Sin reintentos automáticos (1 llamada) |
| **Tarjeta inválida** | `process_payment.side_effect = ValueError` | Lanza `ValueError` | Sin reintentos automáticos (1 llamada) |
| **Sin pasarela** | `ShoppingCart()` sin gateway | Lanza `ValueError` | Error antes de llamar al mock |
| **Monto cero** | `process_payment.return_value = True` | Retorna `True` con monto 0.0 | Una llamada con parámetro 0.0 |

### Contratos validados

**Comportamiento sin reintentos automáticos:**
- El SUT no implementa lógica de reintento automático
- Cada excepción resulta en exactamente 1 llamada al mock
- La responsabilidad de reintentos recae en el cliente

**Manejo de excepciones transparente:**
- Las excepciones de la pasarela se propagan sin modificar
- No hay transformación o wrapping de excepciones
- El cliente recibe el error original para manejo apropiado

**Validación de parámetros:**
- El monto se pasa correctamente calculado (incluye descuentos)
- Se valida la configuración de pasarela antes del procesamiento
- Soporte para montos cero (casos de productos gratuitos)

### Casos de reintento documentados

La prueba `test_pago_timeout_sin_reintento_automatico` incluye documentación explícita del contrato de reintentos:

```python
# El SUT no debe reintentar automáticamente
assert pg.process_payment.call_count == 1

# (Opcional) Reintento manual desde el test para documentar el contrato
pg.process_payment.side_effect = None
pg.process_payment.return_value = True
retry_result = pg.process_payment(total)
assert retry_result is True  # reintento manual exitoso
```

### Patrones de mock identificados

**Configuración de comportamiento:**
- `return_value`: Para respuestas exitosas y rechazos
- `side_effect`: Para excepciones y errores
- Reset de configuración: Para reintentos manuales

**Verificaciones de interacción:**
- `assert_called_once_with()`: Parámetros exactos
- `call_count`: Número de invocaciones
- Timing de llamadas: Antes/después de configuración

### Resultados
- **Contratos validados**: 7/7 escenarios cubiertos
- **Total de pruebas**: 36 pasan, 2 SKIPPED, 2 XFAIL, 2 XPASS (42 totales)
- **Cobertura mantenida**: 93% en shopping_cart.py, 70% total
- **Mock contracts**: Comportamiento de pasarelas externas documentado


## C2: Marcadores de Pruebas para CI/CD

### Implementación

Creamos marcadores personalizados en `tests/test_markers.py`:

- **@pytest.mark.smoke**: 3 pruebas críticas para validación rápida
- **@pytest.mark.regression**: 5 pruebas exhaustivas para estabilidad completa

### Configuración

Registramos los marcadores en `pytest.ini`:
```ini
markers =
    smoke: Pruebas críticas para validación rápida
    regression: Pruebas exhaustivas de estabilidad
```

### Beneficios para CI/CD

1. **Optimización de Pipeline**:
   - Smoke tests (0.15s): Detección temprana de fallas críticas
   - Regression tests (0.25s): Validación completa antes de despliegue

2. **Flexibilidad de Ejecución**:
   - Ejecución selectiva por tipo de prueba
   - Combinaciones con operadores booleanos
   - Exclusión de categorías específicas

3. **Estrategia de Testing**:
   - Feedback inmediato en desarrollo
   - Validación exhaustiva en pre-producción
   - Categorización clara por criticidad

### Impacto en el Desarrollo

- **Desarrolladores**: Feedback rápido con pruebas smoke
- **QA**: Validación completa con regression tests  
- **DevOps**: Pipeline eficiente con ejecución selectiva
- **CI/CD**: Optimización de tiempo y recursos

Este enfoque permite un balance entre velocidad y cobertura, fundamental para desarrollo ágil y despliegue continuo.

## C3: Umbral de Cobertura como Quality Gate

### Implementación del Quality Gate

Se ejecutó el comando con umbral de cobertura del 90%:
```bash
pytest --cov=src --cov-report=term-missing --cov-fail-under=90
```

### Resultado del Quality Gate

**FALLA**: La cobertura total (70%) no alcanza el umbral del 90%

### Análisis de Áreas a Fortalecer

#### 1. src/factories.py (0% cobertura)
- **Estado**: Completamente sin cobertura
- **Líneas faltantes**: 3-11 (todas)
- **Impacto**: Módulo completo sin tests
- **Prioridad**: ALTA

#### 2. src/carrito.py (67% cobertura)
- **Líneas faltantes**: 9, 21, 34-35, 43-52, 60, 64, 68, 82, 97
- **Áreas críticas**:
  - Validaciones de entrada (líneas 43-52)
  - Manejo de casos excepcionales (líneas 60, 64, 68)
  - Funcionalidades de eliminación y actualización (líneas 82, 97)
- **Prioridad**: MEDIA-ALTA

#### 3. src/shopping_cart.py (93% cobertura)
- **Líneas faltantes**: 9, 27
- **Estado**: Buena cobertura, solo casos edge sin cubrir
- **Prioridad**: BAJA

### Estrategia de Mejora

1. **Fase 1** - Crear tests para `factories.py` (+23% cobertura estimada)
2. **Fase 2** - Ampliar cobertura de `carrito.py` validaciones (+15% estimada)
3. **Fase 3** - Completar casos edge de `shopping_cart.py` (+2% estimada)

**Cobertura objetivo**: ~88-90% tras implementación completa

### Quality Gate Status
- **Umbral 90%**: NO CUMPLIDO
- **Cobertura actual**: 70%
- **Brecha**: 20 puntos porcentuales
- **Acción requerida**: Crear tests para módulos no cubiertos

## C4: MREs (Minimal Reproducible Examples) para Defectos

### Implementación

Creamos `tests/test_mre_precision.py` con 4 MREs que documentan defectos identificados en el proyecto:

### MRE 1: Error de Precisión Binaria
```python
def test_mre_precision_float_binary():
    c = ShoppingCart()
    c.add_item("item1", 1, 0.1)  # Item diferente
    c.add_item("item2", 1, 0.2)  # Item diferente  
    # Expectativa: 0.1 + 0.2 = 0.3
    raw_total = c.calculate_total()
    assert abs(raw_total - 0.3) < 1e-10 or round(raw_total, 2) == 0.30
```
**Síntoma**: Posibles errores de precisión en aritmética de punto flotante
**Pasos**: 1) Crear carrito, 2) Agregar items con decimales, 3) Calcular total
**Expectativa**: Total exacto de 0.3

### MRE 2: Acumulación de Errores
```python
def test_mre_precision_accumulated():
    c = ShoppingCart()
    for _ in range(10):
        c.add_item(f"item_{_}", 1, 0.1)  # 10 items de 0.1
    assert round(c.calculate_total(), 2) == 1.00
```
**Síntoma**: Acumulación de errores de precisión con múltiples operaciones
**Pasos**: 1) Agregar 10 items de 0.1, 2) Calcular total acumulado
**Expectativa**: Total de 1.00 exacto

### MRE 3: Contrato Indefinido para Precio Cero
```python
def test_mre_precio_cero_indefinido():
    c = Carrito()
    producto = Producto("test", 0.0)  # Precio cero
    c.agregar_producto(producto, 1)
    assert c.calcular_total() >= 0  # Comportamiento asumido
```
**Síntoma**: Comportamiento no especificado para precios cero/negativos
**Pasos**: 1) Crear producto con precio 0, 2) Agregarlo al carrito, 3) Calcular
**Expectativa**: ¿Debería permitirse? Contrato no define comportamiento

### MRE 4: Diferencias entre Implementaciones
```python
def test_mre_precision_carrito_vs_shopping_cart():
    c1 = Carrito()
    c1.agregar_producto(Producto("x", 0.1), 3)
    c2 = ShoppingCart()  
    c2.add_item("x", 3, 0.1)
    assert round(c1.calcular_total(), 2) == round(c2.calculate_total(), 2)
```
**Síntoma**: Posibles diferencias en manejo de precisión entre clases
**Pasos**: 1) Mismo cálculo en ambas clases, 2) Comparar resultados
**Expectativa**: Ambas implementaciones deberían ser consistentes

### Análisis de Defectos

#### Defectos Identificados en xfail/skip:

1. **test_total_precision_decimal** (xfail)
   - **Ubicación**: `tests/test_rgr_precision_rojo.py`
   - **Síntoma**: "Float binario puede introducir error en dinero"
   - **MRE asociado**: `test_mre_precision_float_binary`

2. **test_precision_binaria_directa** (xfail)  
   - **Ubicación**: `tests/test_rgr_precision_rojo.py`
   - **Síntoma**: "Demostración directa del problema de precisión binaria"
   - **MRE asociado**: `test_mre_precision_accumulated`

3. **test_precios_invalidos** (xfail)
   - **Ubicación**: `tests/test_precios_frontera.py` 
   - **Síntoma**: "Contrato no definido para precio=0 o negativo"
   - **MRE asociado**: `test_mre_precio_cero_indefinido`

### Valor de los MREs

Los MREs proporcionan:
- **Reproducibilidad**: Casos mínimos de 4-6 líneas fáciles de ejecutar
- **Documentación**: Síntomas claros y expectativas definidas  
- **Depuración**: Aislamiento de problemas específicos
- **Comunicación**: Ejemplos concisos para desarrolladores y QA
- **Regresión**: Tests que verifican que los defectos no reaparezcan

Estado: **4 MREs creados y documentados**

## D3: Contrato de Mensajes de Error

### Implementación

Creamos `tests/test_mensajes_error.py` con 6 tests que validan si los mensajes de excepción contienen contexto accionable para usuarios y desarrolladores.

### Análisis de Comportamiento Actual vs Deseado

#### Mensajes Actuales del Sistema (Capturados en Tests)

1. **Cantidad Excesiva en Remoción**:
   ```
   Mensaje actual: "Cantidad a remover es mayor que la cantidad en el carrito"
   Contexto faltante: No especifica cantidad solicitada ni disponible
   ```

2. **Producto Inexistente**:
   ```
   Mensaje actual: "Producto no encontrado en el carrito"  
   Contexto faltante: No incluye nombre específico del producto
   ```

3. **Descuento Inválido**:
   ```
   Mensaje actual: "El porcentaje debe estar entre 0 y 100"
   Contexto faltante: No incluye el valor específico inválido
   ```

#### Tests XFAIL - Contratos Deseados

Implementamos 4 tests marcados como `@pytest.mark.xfail` que documentan los mensajes mejorados esperados:

```python
@pytest.mark.xfail(reason="Esperamos mensaje con nombre de producto inexistente")
def test_mensaje_error_producto_inexistente():
    # Esperado: "Producto 'inexistente' no encontrado en el carrito"
    # Actual: "Producto no encontrado en el carrito"
    assert nombre_inexistente in mensaje

@pytest.mark.xfail(reason="Esperamos mensaje con cantidad específica inválida")  
def test_mensaje_error_cantidad_negativa():
    # Esperado: "Cantidad -5 no válida: debe ser positiva"
    # Actual: Bug en actualizar_cantidad() impide validación
    assert str(cantidad_invalida) in mensaje

@pytest.mark.xfail(reason="Esperamos mensaje con cantidad excesiva específica")
def test_mensaje_error_cantidad_excesiva():
    # Esperado: "No se pueden remover 5 items, solo hay 2 disponibles"
    # Actual: "Cantidad a remover es mayor que la cantidad en el carrito"
    assert str(cantidad_excesiva) in mensaje and "3" in mensaje

@pytest.mark.xfail(reason="Esperamos mensaje descriptivo sobre porcentaje inválido")
def test_mensaje_error_descuento_invalido():
    # Esperado: "Descuento 150% inválido, debe estar entre 0% y 100%"
    # Actual: "El porcentaje debe estar entre 0 y 100"
    assert str(porcentaje_invalido) in mensaje
```

### Por qué los Mensajes Actuales NO Proveen Contexto Accionable

#### Problemas Identificados:

1. **Falta de Especificidad**:
   - No incluyen valores específicos que causaron el error
   - Imposible saber qué producto o cantidad específica falló

2. **Información Insuficiente para Debugging**:
   - Desarrolladores necesitan más contexto para diagnosticar
   - Logs de error genéricos dificultan troubleshooting

3. **UX Deficiente**:
   - Usuarios no saben exactamente qué corregir
   - Mensajes genéricos frustran la experiencia del usuario

4. **Mantenimiento Complicado**:
   - Difícil rastrear origen específico de errores
   - Testing manual requerido para reproducir contextos específicos

### Contratos de Mensajes Mejorados (Documentados con XFAIL)

#### Tabla de Mejoras Propuestas:

| Escenario | Mensaje Actual | Mensaje Deseado | Contexto Agregado |
|-----------|----------------|------------------|-------------------|
| **Producto inexistente** | "Producto no encontrado" | "Producto 'laptop' no encontrado" | Nombre específico |
| **Cantidad excesiva** | "Cantidad mayor que disponible" | "No remover 5, solo hay 2 disponibles" | Cantidades numéricas |
| **Descuento inválido** | "Entre 0 y 100" | "Descuento 150% inválido, use 0-100%" | Valor proporcionado |
| **Cantidad negativa** | (Bug impide validación) | "Cantidad -5 inválida, use valor positivo" | Valor específico |

### Valor de los Contratos de Mensajes Mejorados

#### Beneficios para Usuarios:
1. **Feedback Específico**: Saben exactamente qué corregir
2. **Menos Frustración**: Errores auto-explicativos
3. **Onboarding Mejorado**: Nuevos usuarios entienden restricciones
4. **Productividad**: Menos tiempo perdido adivinando problemas

#### Beneficios para Desarrolladores:
1. **Debugging Acelerado**: Contexto inmediato del problema
2. **Logs Útiles**: Trazabilidad específica en sistemas de monitoreo
3. **Testing Simplificado**: Validación precisa de casos edge
4. **Mantenimiento**: Identificación rápida de problemas en producción

#### Beneficios para APIs:
1. **Respuestas Informativas**: Clientes reciben contexto detallado
2. **Documentación Automática**: Mensajes sirven como especificación
3. **Integración**: Sistemas externos pueden manejar errores específicos
4. **Versionado**: Mensajes consistentes entre versiones

### Implementación Técnica Recomendada

Para implementar estos contratos mejorados:

```python
# Ejemplo de mensaje mejorado:
def remover_producto(self, producto, cantidad):
    item_actual = self.find_item(producto.nombre)
    if not item_actual:
        raise ValueError(f"Producto '{producto.nombre}' no encontrado en el carrito")
    
    if cantidad > item_actual.cantidad:
        raise ValueError(
            f"No se pueden remover {cantidad} items de '{producto.nombre}', "
            f"solo hay {item_actual.cantidad} disponibles"
        )
```

### Estado del Sistema Actual

- **2 tests PASAN**: Funciones que funcionan correctamente
- **4 tests XFAIL**: Contratos deseados documentados para futuras mejoras  
- **Bug identificado**: `actualizar_cantidad()` impide algunas validaciones
- **Gap de UX**: Mensajes genéricos requieren mejora sistemática

Los contratos XFAIL sirven como especificación ejecutable de los mensajes de error mejorados que beneficiarían significativamente la experiencia del usuario y la capacidad de mantenimiento del sistema.

Estado: **Contratos de mensajes documentados con 4 XFAIL para mejoras de UX**
